from abc import abstractmethod, ABC
from datetime import datetime


class RejectObserver:
    @abstractmethod
    def update(self, message: str):
        pass
