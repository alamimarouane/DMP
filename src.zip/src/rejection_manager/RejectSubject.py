from pandas.core.interchange.dataframe_protocol import DataFrame

from src.rejection_manager.RejectObserver import RejectObserver


class RejectSubject:
    def __init__(self):
        self._observers = []

    def attach(self, observer: RejectObserver):
        self._observers.append(observer)

    def detach(self, observer: RejectObserver):
        self._observers.remove(observer)

    def handle(self, rejections: DataFrame):
        for observer in self._observers:
            observer.update(rejections)