from pandas.core.interchange.dataframe_protocol import DataFrame

from src.rejection_manager.RejectObserver import RejectObserver


class RejectHandler(RejectObserver):
    def update(self, rejections: DataFrame):
        pass