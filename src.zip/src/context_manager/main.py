from src.context_manager.JsonAccessorManager import JsonAccessorManager

if __name__ == '__main__':

# Exemple d'utilisation
    manager = JsonAccessorManager()
    manager.add_from_directory("../../metadata")
    #manager.add_from_directory("../../config")
    accessor = manager.get("shared-shared_config")
    if accessor:
        print(accessor.get_runtime_config_execution_date())  # mysql, si le JSON contient ces données
