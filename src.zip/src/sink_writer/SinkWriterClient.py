from src.context_manager.JsonAccessorManager import JsonAccessorManager
from src.logger import LogHandler
from src.sink_writer.SinkWriterFactory import SinkWriterFactory
import pandas as pd


class SinkWriterClient:
    def __init__(self, key:str, accessor_manager: JsonAccessorManager, factory: SinkWriterFactory, logger: LogHandler):
        self.sink_writer = factory.create_sink_writer()

        self.key = key
        self.accessor_manager = accessor_manager
        self.flow_accessor = accessor_manager.get(self.key)
        self.logger = logger

    def write_data(self, df: pd.DataFrame, destination: str):
        self.sink_writer.write(df, destination)
        message = f"Ecriture des données : {destination} nombre de ligne(s) {self.get_written_rows_count(destination)}"
        self.logger.log_step(message)
        return len(df), self.get_written_rows_count(destination)

    def get_written_rows_count(self, destination: str) -> int:
        """
        Retourne le nombre de lignes écrites dans le fichier en comptant les lignes du fichier.
        """
        try:
            with open(destination, 'r', encoding='utf-8') as file:
                return sum(1 for _ in file) - 1  # En supposant qu'il y a un en-tête
        except Exception as e:
            print(f"Erreur lors de la lecture du fichier {destination}: {e}")
            return 0
