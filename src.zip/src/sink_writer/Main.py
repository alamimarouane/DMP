import pandas as pd

from src.sink_writer.FileSinkWriterFactory import FileSinkWriterFactory
from src.sink_writer.SinkWriterClient import SinkWriterClient

if __name__ == "__main__":
    df = pd.DataFrame({'col1': [1, 2], 'col2': [3, 4]})

    # Écriture en local
    file_factory = FileSinkWriterFactory()
    file_client = SinkWriterClient(file_factory)
    file_client.write_data(df, "output.csv")
