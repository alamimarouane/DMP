from abc import ABC, abstractmethod
import pandas as pd

# ---- Abstract Product ----
class SinkWriter(ABC):
    @abstractmethod
    def write(self, df: pd.DataFrame, destination: str):
        pass