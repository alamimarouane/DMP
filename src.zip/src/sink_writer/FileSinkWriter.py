
from src.sink_writer.SinkWriter import SinkWriter
import pandas as pd
import os

from src.sink_writer.SinkWriterClient import SinkWriterClient


class FileSinkWriter(SinkWriter):
    def write(self, df: pd.DataFrame, destination: str):
        directory = os.path.dirname(destination)
        if directory and not os.path.exists(directory):
            os.makedirs(directory)

        df.to_csv(destination, index=False)

