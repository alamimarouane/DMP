from src.sink_writer.FileSinkWriter import FileSinkWriter
from src.sink_writer.SinkWriter import SinkWriter
from src.sink_writer.SinkWriterFactory import SinkWriterFactory


class FileSinkWriterFactory(SinkWriterFactory):
    def create_sink_writer(self) -> SinkWriter:
        return FileSinkWriter()