from abc import abstractmethod, ABC

from src.sink_writer.SinkWriter import SinkWriter


class SinkWriterFactory(ABC):
    @abstractmethod
    def create_sink_writer(self) -> SinkWriter:
        pass