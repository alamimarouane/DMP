from src.transformationManager.TransformationStrategy import TransformationStrategy
import pandas as pd

class BooleanTransformation(TransformationStrategy):
    def transform(self, value):
        return str(value).strip().lower() in ['true', '1', 'yes'] if pd.notna(value) else None

