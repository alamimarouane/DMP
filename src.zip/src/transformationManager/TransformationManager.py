from src.transformationManager.BooleanTransformation import BooleanTransformation
from src.transformationManager.DateTimeTransformation import DateTimeTransformation
from src.transformationManager.DecimalTransformation import DecimalTransformation
from src.transformationManager.IntegerTransformation import IntegerTransformation
from src.transformationManager.StripWhitespaceTransformation import StripWhitespaceTransformation
from src.transformationManager.UppercaseTransformation import UppercaseTransformation
import pandas as pd
from datetime import datetime


class TransformationManager:
    def __init__(self, rejection_manager, metadata):
        self.rejection_manager = rejection_manager
        self.metadata = metadata
        self.strategies = {
            'integer': IntegerTransformation(),
            'decimal': DecimalTransformation(),
            'datetime': DateTimeTransformation(),
            'boolean': BooleanTransformation()
        }

    def apply_transformation(self, df):
        transformed_rows = []
        rejected_rows = []

        for index, row in df.iterrows():
            new_row = row.to_dict()  # 🔹 Convertir en dictionnaire pour garantir la modification
            rejected_info = None

            try:
                # Apply type casting transformations
                for column, dtype in self.metadata['type_casting']['columns'].items():
                    if column in df.columns and dtype in self.strategies:
                        try:
                            new_row[column] = self.strategies[dtype].transform(row[column])
                        except Exception as e:
                            rejected_info = {
                                'index': index,
                                'column': column,
                                'value': row[column],
                                'cause': dtype,
                                'error': str(e),
                                'rejection_datetime': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                            }
                            raise e

                # Apply whitespace stripping transformations
                for column in self.metadata['strip_whitespace']['columns']:
                    if column in df.columns and isinstance(new_row[column], str):  # Vérifier si c'est bien une chaîne
                        transformed_value = StripWhitespaceTransformation().transform(new_row[column])

                        new_row[column] = transformed_value  # 🔹 Modifier directement le dictionnaire

                # Apply custom transformations
                for transformation in self.metadata['custom_transformations']:
                    if transformation['operation'] == 'uppercase':
                        for column in transformation['columns']:
                            if column in df.columns and isinstance(new_row[column], str):
                                new_row[column] = UppercaseTransformation().transform(new_row[column])

                transformed_rows.append(pd.Series(new_row))  # 🔹 Convertir en Series avant ajout

            except Exception:
                if rejected_info:
                    rejected_rows.append(rejected_info)

        # Create DataFrame for rejected rows
        rejected_df = pd.DataFrame(rejected_rows)

        # Notify rejection manager with consolidated DataFrame
        if not rejected_df.empty:
            self.rejection_manager.notify(rejected_df)

        # Create transformed DataFrame, keeping original structure
        transformed_df = pd.DataFrame(transformed_rows, columns=df.columns)

        return transformed_df
