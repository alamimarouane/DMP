import pandas as pd

# Observer Pattern: RejectionManager
class RejectionManager:
    def __init__(self):
        self.rejections = pd.DataFrame(columns=['index', 'column', 'value', 'cause', 'error', 'rejection_datetime'])

    def notify(self, rejected_df):
        self.rejections = pd.concat([self.rejections, rejected_df], ignore_index=True)

    def get_rejections(self):
        return self.rejections
