
import pandas as pd

from src.transformationManager.TransformationStrategy import TransformationStrategy


class IntegerTransformation(TransformationStrategy):
    def transform(self, value):
        return int(value) if pd.notna(value) else None
