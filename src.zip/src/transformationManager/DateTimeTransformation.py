from src.transformationManager.TransformationStrategy import TransformationStrategy
import pandas as pd

class DateTimeTransformation(TransformationStrategy):
    def transform(self, value):
        return pd.to_datetime(value, errors='coerce') if pd.notna(value) else None