from src.source_reader.JsonSourceReader import JsonSourceReader
from src.transformationManager.RejectionManager import RejectionManager


import pandas as pd
from src.transformationManager.TransformationManager import TransformationManager

if __name__ == '__main__':

    # Exemple d'utilisation

    json_reader = JsonSourceReader()
    config = json_reader.read("Shared_config", "../../config/shared_config.json", False)

    metadata_path = config.get("global_config")[
                        "scoped_metadata_root"] + "/" + "morocco" + "/" + "sgma" + "/" + "delta" + "/" + "bksldf" + ".json"
    #metadata = json_reader.read("bksldf", metadata_path, False)
    #print(metadata.get(""))

    data = {
        'id': ['1', '2', 'abc', '4'],
        'age': ['25', '30', 'xyz', '40'],
        'salary': ['50000.5', '60000', '70000.3', 'invalid'],
        'start_date': ['2021-06-01', '2022-01-15', 'invalid_date', '2023-03-10'],
        'last_login': ['2024-01-01 12:30', '2024-02-02 14:00', 'wrong_format', '2024-02-10 16:45'],
        'score': ['88.5', '92.3', 'N/A', '75.2'],
        'is_verified': ['true', 'False', 'yes', 'no'],
        'name': [' Alice ', 'Bob', 'charlie', 'DAVID '],
        'status': [' active ', 'INACTIVE', 'pending', 'Active']
    }
    df = pd.DataFrame(data)

    metadata = {
            "type_casting": {
                "columns": {
                    "id": "integer",
                    "age": "integer",
                    "salary": "decimal",
                    "start_date": "datetime",
                    "last_login": "datetime",
                    "score": "decimal",
                    "is_verified": "boolean"
                }
            },
            "strip_whitespace": {
                "columns": ["name", "status"]
            },
            "custom_transformations": [
                {
                    "operation": "uppercase",
                    "columns": ["name", "status"]
                }
            ]
    }

    rejection_manager = RejectionManager()
    transformation_manager = TransformationManager(rejection_manager, metadata)
    df_transformed = transformation_manager.apply_transformation(df)

    print("DataFrame Transformé:")
    print(df_transformed)
    print("\nRejets:")
    print(rejection_manager.get_rejections())