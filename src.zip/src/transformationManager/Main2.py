import pandas as pd
from datetime import datetime

# Définition des transformations
converters = {
    "id": int,
    "name": lambda x: x.strip().upper(),  # Supprime les espaces et met en majuscule
    "age": int,
    "salary": lambda x: round(float(x), 2),  # Convertit en float avec 2 décimales
    "start_date": lambda x: datetime.strptime(x, "%Y-%m-%d"),  # Transforme en datetime
    "last_login": lambda x: datetime.strptime(x, "%Y-%m-%dT%H:%M:%S") if x else None,  # Gère les valeurs vides
    "status": lambda x: x.strip().upper(),  # Nettoyage + majuscules
    "score": lambda x: round(float(x), 1),  # Score avec une décimale
    "email": str,  # Assurer le type string
    "is_verified": lambda x: x.lower() in ["true", "1", "yes"]  # Convertir en booléen
}

# Lecture avec transformation
df = pd.read_csv("../../data/20250123/morocco/sgma/delta/bksldf.csv", delimiter=",", converters=converters)

print(df.dtypes)  # Vérifier les types
print(df.head())  # Afficher un aperçu
