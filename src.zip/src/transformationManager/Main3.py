from src.context_manager.JsonAccessorManager import JsonAccessorManager
from src.exception_manager.ExceptionManager import ExceptionManager
from src.source_reader.JsonSourceReader import JsonSourceReader
from src.ingestion.FlowIngestionProcess import FlowIngestionProcess

if __name__ == '__main__':
    json_reader = JsonSourceReader()
    config = json_reader.read("Shared_config", "../../config/shared_config.json", False)

    exception_manager = ExceptionManager(config.get("global_config").get("exceptions_config"))
    exception_manager.setup_handlers()
    manager = JsonAccessorManager()
    manager.add_from_directory("../../metadata/scoped")
    manager.add_from_directory("../../config")
    process = FlowIngestionProcess(config, manager, "morocco", "sgma", "delta", "bksldf", exception_manager)
    process.run()

