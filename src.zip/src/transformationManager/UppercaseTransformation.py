from src.transformationManager.TransformationStrategy import TransformationStrategy
import pandas as pd

class UppercaseTransformation(TransformationStrategy):
    def transform(self, value):
        return value.upper() if isinstance(value, str) else value