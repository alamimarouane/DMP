# Strategy Pattern: Transformation Strategy
from abc import abstractmethod, ABC


class TransformationStrategy(ABC):
    @abstractmethod
    def transform(self, value):
        pass