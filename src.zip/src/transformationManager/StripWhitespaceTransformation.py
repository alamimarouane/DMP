from src.transformationManager.TransformationStrategy import TransformationStrategy
import pandas as pd

class StripWhitespaceTransformation(TransformationStrategy):
    def transform(self, value):
        if pd.isna(value):  # Vérifie si la valeur est NaN
            return value
        if isinstance(value, str):
            stripped_value = value.strip()
            return stripped_value
        return value
