# Initialisation du LogHandler
import time



import threading
import time

from src.logger.LogHandler import LogHandler
from src.source_reader.JsonSourceReader import JsonSourceReader

if __name__ == "__main__":
    json_reader = JsonSourceReader()
    config = json_reader.read("Shared_config", "../../config/shared_config.json", False)
    #context = GlobalConfig(config_file="C:\\Users\\alami\\PycharmProjects\\Pipelines\\config\\context.json")
    log = LogHandler(config, "Ingestion")
    log.log_start(1, "Démarrage Yassine")
    time.sleep(2)
    log.log_step("Etape 1")
    time.sleep(2)
    log.log_step("Etape 2")
    time.sleep(2)
    log.log_step("Etape 3")
    time.sleep(2)
    log.log_complete(0, "Fin de traitement")


