import os
from datetime import datetime, time

from src.context_manager.JsonAccessorManager import JsonAccessorManager
from src.logger.DataProcess import DataProcess
from src.sink_writer.log_writer.LogPrintWriter import LogPrintWriter


class LogHandler:
    def __init__(self, accessor_manager: JsonAccessorManager, phase):
        self.accessor_manager = accessor_manager
        self.data_process = DataProcess(self.accessor_manager, phase)
        self.sink_writer = LogPrintWriter()
        #self.sink_writer.log_data_process(self.data_process.to_dict())

    def log_start(self, code, message="Processing started"):
        """
        Appelle la méthode start sur l'objet DataProcess.
        """
        self.data_process.start(code, message)
        self.sink_writer.log_data_process(self.data_process.to_dict())



    def log_complete(self, code, message="Process completed successfully"):
        """
        Appelle la méthode complete sur l'objet DataProcess.
        """
        self.data_process.complete(code, message)
        self.sink_writer.log_data_process(self.data_process.to_dict())


    def log_fail(self, code, message="Process failed"):
        """
        Appelle la méthode fail sur l'objet DataProcess.
        """
        self.data_process.fail(code, message)
        self.sink_writer.log_data_process(self.data_process.to_dict())


    def log_step(self, message):
        """
        Ajoute une étape au processus en cours.
        """
        self.data_process.add_step(message)
        step = self.data_process.get_last_step()
        self.sink_writer.log_data_process_step(self.data_process.get_last_step().to_dict())



