from src.context_manager.JsonAccessorManager import JsonAccessorManager
from src.exception_manager.ExceptionHandler import ExceptionHandler
import json

from src.logger.LogHandler import LogHandler


class ExceptionManager:
    """
    Gestionnaire central pour enregistrer les handlers et charger la configuration des exceptions.
    """
    def __init__(self, accessor_manager: JsonAccessorManager):
        self.accessor_manager = accessor_manager
        config_path = self.accessor_manager.get("shared_config").get_global_config_exceptions_config()
        self.chain = None
        self.config = self._load_config(config_path)

    def _load_config(self, config_path):
        """
        Charge la configuration des exceptions à partir d'un fichier JSON.
        """
        try:
            with open(config_path, "r") as f:
                return json.load(f)
        except Exception as e:
            raise RuntimeError(f"Erreur lors du chargement du fichier JSON: {e}")

    def setup_handlers(self):
        """
        Configure les gestionnaires d'exceptions en fonction de la configuration chargée.
        """
        handler = ExceptionHandler(self.config)
        self.register_handler(handler)

    def register_handler(self, handler):
        """
        Enregistre un gestionnaire dans la chaîne de responsabilité.
        """
        if self.chain:
            current = self.chain
            while current.next_handler:
                current = current.next_handler
            current.set_next(handler)
        else:
            self.chain = handler

    def handle(self, exception, context):
        """
        Passe l'exception dans la chaîne de gestionnaires.
        """
        if self.chain:

            self.chain.handle_exception(exception, context)
        else:
            print("Aucun gestionnaire enregistré.")

    def get_error_info(self, exception):
        """
        Récupère les informations de l'erreur à partir de l'exception.
        """
        exception_type = type(exception).__name__
        error_info = self.config.get(exception_type, self.config.get("default_error"))
        return error_info
