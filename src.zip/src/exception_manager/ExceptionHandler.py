from src.exception_manager.BaseExceptionHandler import BaseExceptionHandler



class ExceptionHandler(BaseExceptionHandler):
    """
    Gestionnaire d'exceptions pour traiter toutes les erreurs.
    """
    def __init__(self, config, next_handler=None):
        super().__init__(next_handler)
        self.config = config

    def handle_exception(self, exception, context):
        error_info = self.get_error_info(exception)
        #my_error = self.get_exception_info(error_info["code"], error_info["message"])
        print(f"[Handler] avec contexte: {context}")



    def get_error_info(self, exception):
        """
        Récupère les informations de l'erreur à partir de la configuration JSON.
        """
        exception_type = type(exception).__name__
        return self.config.get(exception_type, self.config.get("default_error"))