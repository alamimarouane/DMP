import pandas as pd
from datetime import datetime

from src.transformationManager_Save.TransformationStrategy import TransformationStrategy


class StripWhiteSpaceStrategy(TransformationStrategy):
    def __init__(self, flow_name):
        self.flow_name = flow_name  # Nom du flux
        self.rejections = []  # Liste des rejets

    def apply(self, df: pd.DataFrame, columns: list, **kwargs) -> pd.DataFrame:
        """
        Applique la suppression des espaces blancs autour des valeurs des colonnes spécifiées et capture les rejets.

        :param df: DataFrame cible.
        :param columns: Liste des colonnes à traiter.
        :return: DataFrame transformée.
        """
        for column in columns:
            # Vérifier si la colonne existe dans le DataFrame
            if column not in df.columns:
                self.rejections.append({
                    "flow_name": self.flow_name,
                    "datetime": datetime.now().isoformat(),
                    "column": column,
                    "value": None,
                    "cause": "Column does not exist in the DataFrame",
                    "proposition": f"Ensure the column '{column}' exists in the source data."
                })
                continue

            # Appliquer la suppression des espaces blancs
            try:
                # Identifier les valeurs non `str`
                non_string_rows = df[~df[column].apply(lambda x: isinstance(x, str))]
                if not non_string_rows.empty:
                    self._capture_rejections(df, column, non_string_rows)

                # Supprimer les espaces blancs autour des chaînes

                df[column] = df[column].map(
                    lambda x: x.strip() if isinstance(x, str) else x
                )

            except Exception as e:
                # Capture des erreurs générales lors du traitement
                self.rejections.append({
                    "flow_name": self.flow_name,
                    "datetime": datetime.now().isoformat(),
                    "column": column,
                    "value": None,
                    "cause": f"Error during whitespace stripping: {e}",
                    "proposition": "Verify the data and ensure all values are strings before processing."
                })

        return df

    def _capture_rejections(self, df: pd.DataFrame, column: str, rejected_rows: pd.DataFrame):
        """
        Capture les valeurs rejetées qui ne sont pas des chaînes de caractères.

        :param df: DataFrame transformée.
        :param column: Colonne concernée.
        :param rejected_rows: Lignes contenant des valeurs non conformes.
        """
        for index, row in rejected_rows.iterrows():
            self.rejections.append({
                "flow_name": self.flow_name,
                "datetime": datetime.now().isoformat(),
                "column": column,
                "line_number": index + 1,  # Numéro de ligne 1-based
                "value": row[column],
                "cause": "Value is not a string",
                "proposition": f"Ensure the value in column '{column}' is a string."
            })

    def get_rejections(self):
        """
        Retourne la liste des rejets capturés.

        :return: Liste des rejets.
        """
        return self.rejections
