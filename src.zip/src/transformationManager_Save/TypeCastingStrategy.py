from src.transformationManager_Save.TransformationStrategy import TransformationStrategy
import pandas as pd
from datetime import datetime
from decimal import Decimal, InvalidOperation

class TypeCastingStrategy(TransformationStrategy):
    def __init__(self, flow_name):
        self.flow_name = flow_name  # Nom du flux
        self.rejections = []  # Liste des rejets

    def apply(self, df: pd.DataFrame, columns: dict, **kwargs) -> pd.DataFrame:
        """
        Applique la conversion de type sur les colonnes spécifiées et capture les rejets.

        :param df: DataFrame cible.
        :param columns: Dictionnaire {colonne: type}.
        :return: DataFrame transformé.
        """
        for column, dtype in columns.items():
            # Vérifier si la colonne existe dans le DataFrame
            if column not in df.columns:
                self.rejections.append({
                    "flow_name": self.flow_name,
                    "datetime": datetime.now().isoformat(),
                    "column": column,
                    "value": None,
                    "cause": "Column does not exist in the DataFrame",
                    "proposition": f"Ensure the column '{column}' exists in the source data."
                })
                continue

            # Appliquer la conversion de type
            try:
                if dtype == "datetime":
                    df[column] = pd.to_datetime(df[column], errors="coerce")
                    self._capture_rejections(df, column, dtype)

                elif dtype == "integer":
                    df[column] = pd.to_numeric(df[column], errors="coerce").astype("Int64")
                    self._capture_rejections(df, column, dtype)

                elif dtype == "float":
                    df[column] = pd.to_numeric(df[column], errors="coerce")
                    self._capture_rejections(df, column, dtype)

                elif dtype == "decimal":
                    df[column] = df[column].apply(self._convert_to_decimal)
                    self._capture_rejections(df, column, dtype)

                elif dtype == "boolean":
                    df[column] = df[column].astype(bool)

                else:
                    df[column] = df[column].astype(dtype)

            except Exception as e:
                # Capture des erreurs de transformation générales
                self.rejections.append({
                    "flow_name": self.flow_name,
                    "datetime": datetime.now().isoformat(),
                    "column": column,
                    "value": None,
                    "cause": f"Error during type casting: {e}",
                    "proposition": "Verify the data type or correct the source value."
                })

        return df

    def _convert_to_decimal(self, value):
        """
        Convertit une valeur en `decimal.Decimal`, capture les erreurs si la conversion échoue.

        :param value: La valeur à convertir.
        :return: La valeur convertie en `Decimal` ou NaN en cas d'échec.
        """
        try:
            return Decimal(str(value)) if pd.notna(value) else None
        except (InvalidOperation, ValueError):
            return None

    def _capture_rejections(self, df: pd.DataFrame, column: str, dtype: str):
        """
        Capture les valeurs rejetées après une conversion de type.

        :param df: DataFrame transformée.
        :param column: Colonne concernée.
        :param dtype: Type cible de conversion.
        """
        rejected_rows = df[df[column].isna()]  # Identifie les NaN comme rejets
        for index, row in rejected_rows.iterrows():
            self.rejections.append({
                "flow_name": self.flow_name,
                "datetime": datetime.now().isoformat(),
                "column": column,
                "value": row[column],
                "cause": f"Cannot convert to {dtype}",
                "proposition": f"Ensure the value in column '{column}' matches the expected type '{dtype}'."
            })

    def get_rejections(self):
        """
        Retourne la liste des rejets capturés.

        :return: Liste des rejets.
        """
        return self.rejections
