from abc import ABC, abstractmethod
import pandas as pd


class TransformationStrategy(ABC):
    """
    Interface pour les stratégies de transformation des colonnes d'une DataFrame.
    """

    @abstractmethod
    def apply(self, df: pd.DataFrame, columns: list, **kwargs) -> pd.DataFrame:
        """
        Applique une transformation sur les colonnes spécifiées de la DataFrame.

        :param df: DataFrame cible.
        :param columns: Liste des colonnes à transformer.
        :param kwargs: Arguments supplémentaires pour la transformation.
        :return: DataFrame transformée.
        """
        pass
