from src.context_manager.DataContext import DataContext
from src.rejection_manager.RejectSubject import RejectSubject
from src.transformationManager_Save.StripWhiteSpaceStrategy import StripWhiteSpaceStrategy
from src.transformationManager_Save.TypeCastingStrategy import TypeCastingStrategy
from src.transformationManager_Save.UpperCaseStrategy import UpperCaseStrategy
import pandas as pd


class TransformationManager(RejectSubject):
    def __init__(self, data_context: DataContext):
        super().__init__()
        self.metadata = data_context.get_metadata()
        self.flow_name = self.metadata.get("flow_name")  # Nom du flux
        self.rules = self.metadata.get("transformation_rules")
        self.data = data_context.get_data()
        self.strategies = {
            "type_casting": TypeCastingStrategy(self.flow_name),
            "uppercase": UpperCaseStrategy(self.flow_name),
            "strip_whitespace": StripWhiteSpaceStrategy(self.flow_name)
        }
        self.rejections = []  # Liste pour stocker tous les rejets

    def apply_transformations(self) -> pd.DataFrame:
        """
        Applique les transformations spécifiées dans les règles sur la DataFrame.

        :return: DataFrame transformée.
        """
        # 1. Appliquer les transformations de type casting
        type_casting_rules = self.rules.get("type_casting", {}).get("columns", {})
        if type_casting_rules:
            strategy = self.strategies["type_casting"]
            self.data = strategy.apply(self.data, columns=type_casting_rules)
            self.rejections.extend(strategy.get_rejections())

        # 2. Appliquer les transformations personnalisées
        custom_transformations = self.rules.get("custom_transformations", [])
        for transformation in custom_transformations:
            operation = transformation.get("operation")
            columns = transformation.get("columns", [])

            # Vérifier si l'opération est prise en charge
            if operation in self.strategies:
                strategy = self.strategies[operation]
                self.data = strategy.apply(self.data, columns=columns)

                # Collecter les rejets si la stratégie en produit
                if hasattr(strategy, "get_rejections"):
                    self.rejections.extend(strategy.get_rejections())

        # 3. Appliquer la suppression des espaces blancs
        strip_whitespace_rules = self.rules.get("strip_whitespace", {}).get("columns", [])
        if strip_whitespace_rules:
            strategy = self.strategies["strip_whitespace"]
            self.data = strategy.apply(self.data, columns=strip_whitespace_rules)
            self.rejections.extend(strategy.get_rejections())
        self.handle(self.get_rejections_as_dataframe())
        return self.data

    def get_rejections(self):
        """
        Retourne tous les rejets capturés par les stratégies.

        :return: Liste des rejets.
        """
        return self.rejections

    def get_rejections_as_dataframe(self) -> pd.DataFrame:
        """
        Convertit les rejets en un DataFrame structuré.

        :return: DataFrame des rejets.
        """
        if not self.rejections:
            return pd.DataFrame()

        # Assurez-vous que chaque rejet est un dictionnaire pour créer un DataFrame
        if all(isinstance(rejection, dict) for rejection in self.rejections):
            return pd.DataFrame(self.rejections)
        else:
            # Si les rejets ne sont pas des dictionnaires, les formater
            return pd.DataFrame([{"rejection": rejection} for rejection in self.rejections])
def get_rejections_as_dataframe(self) -> pd.DataFrame:
    """
    Convertit les rejets en un DataFrame structuré.

    :return: DataFrame des rejets.
    """
    if not self.rejections:
        return pd.DataFrame(columns=["column", "value", "error"])  # Définir des colonnes par défaut

    if all(isinstance(rejection, dict) for rejection in self.rejections):
        return pd.DataFrame(self.rejections)
    else:
        return pd.DataFrame([{"rejection": str(rejection)} for rejection in self.rejections])
