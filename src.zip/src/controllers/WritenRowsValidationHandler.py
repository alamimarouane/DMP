from typing import Dict, List
import csv

from src.context_manager.JsonAccessorManager import JsonAccessorManager
from src.controllers.ControleHandler import ControleHandler
from src.logger.LogHandler import LogHandler


class WritenRowsValidationHandler(ControleHandler):

    def handle(self, key:str, accessor_manager: JsonAccessorManager, logger: LogHandler):
        self.key = key
        self.accessor_manager = accessor_manager
        self.flow_accessor = accessor_manager.get(self.key)
        self.logger = logger
        # Validation de la structure du fichier
        # Appeler le maillon suivant si nécessaire

        if not self._validate_writen_rows_number():
            return False
        return super().handle(self.key, self.accessor_manager, self.logger)

    def _validate_writen_rows_number(self):
        # Placeholder pour la validation de la structure
        result = True
        return result