from src.context_manager.JsonAccessorManager import JsonAccessorManager
from src.controllers.StructureValidationHandler import StructureValidationHandler
from src.controllers.WritenRowsValidationHandler import WritenRowsValidationHandler
from src.logger.LogHandler import LogHandler


class DataValidator:
    def __init__(self, validation_rules_type: str, key: str, accessor_manager: JsonAccessorManager, logger: LogHandler):
        self.key = key
        self.accessor_manager = accessor_manager
        self.flow_accessor = accessor_manager.get(self.key)
        self.logger = logger

        if validation_rules_type == "pre_validation_rules":
            validation_rules = self.flow_accessor.get_pre_validation_rules()
            handler_classes = {
                "StructureValidationHandler": StructureValidationHandler,
            }
        else:
            if validation_rules_type == "post_validation_rules":
                validation_rules = self.flow_accessor.get_post_validation_rules()
                handler_classes = {
                    "WritenRowsValidationHandler": WritenRowsValidationHandler
                }

        self.handler_instances = [handler_classes[name] for name in validation_rules if name in handler_classes]

        self.chain = self._build_chain(self.handler_instances)

    def _build_chain(self, handlers):
        """
        Construit dynamiquement la chaîne de responsabilité à partir d'une liste de gestionnaires.
        """
        if not handlers:
            return None

        head = handlers[0]()
        current = head

        for handler_class in handlers[1:]:
            next_handler = handler_class()
            current.successor = next_handler
            current = next_handler

        return head

    def validate(self):
        if self.chain:
            return self.chain.handle(self.key, self.accessor_manager, self.logger)
        return True
