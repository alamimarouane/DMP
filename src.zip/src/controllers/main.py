from src.controllers.DataValidationHandler import DataValidationHandler
from src.controllers.DataValidator import DataValidator
from src.controllers.StructureValidationHandler import StructureValidationHandler

if __name__ == '__main__':
    system_source = "sgma/dlt"
    file_name = "bkcdl"

    metadata = MetadataLoader.load_metadata(system_source, file_name)

    file = FilesSourceReader()
    data = file.read_data(system_source, file_name)

    handler_classes = {
        "StructureValidationHandler": StructureValidationHandler,
        "DataValidationHandler": DataValidationHandler
    }
    handlers = metadata.get("validators", [])

    handler_instances = [handler_classes[name] for name in handlers if name in handler_classes]


    validator = DataValidator(handler_instances)


    if validator.validate(data):
        print("Data is valid.")
    else:
        print("Data is invalid.")




"""
    chain = StructureValidationHandler()
    chain.handle(data)

    # Liste dynamique des gestionnaires
    

    # Création du validateur de fichiers
    
"""
