from typing import Dict, List
import csv

from src.context_manager.JsonAccessorManager import JsonAccessorManager
from src.controllers.ControleHandler import ControleHandler
from src.logger.LogHandler import LogHandler


class StructureValidationHandler(ControleHandler):

    def handle(self, key:str, accessor_manager: JsonAccessorManager, logger: LogHandler):
        self.key = key
        self.accessor_manager = accessor_manager
        self.flow_accessor = accessor_manager.get(self.key)
        self.logger = logger
        # Validation de la structure du fichier
        # Appeler le maillon suivant si nécessaire

        if not self._validate_structure():
            return False
        return super().handle(self.key, self.accessor_manager, self.logger)

    def _validate_structure(self):
        # Placeholder pour la validation de la structure

        #metadata_columns = data_context.get_metadata().get("schema").get("columns")
        key_to_path = self.key.replace("-", "/")
        metadata_columns = self.flow_accessor.get_schema_columns()
        file_path = self.flow_accessor.get("data_file_path")
        delimiter = self.flow_accessor.get_source_delimiter()
        result, self.mismatches = self._validate_csv_header(metadata_columns, file_path, delimiter)
        self.logger.log_step(self.mismatches)
        return result

    def get_mismatches(self):
        return self.mismatches


    def _validate_csv_header(self, json_schema: Dict[str, Dict], file_path: str, delimiter: str = ",") -> Dict[str, List[str]]:
        """
        Compare l'entête du fichier CSV avec la structure JSON en termes de nombre, ordre et nomenclature des colonnes.

        :param json_schema: Structure JSON définissant les colonnes attendues
        :param file_path: Chemin du fichier CSV à valider
        :param delimiter: Délimiteur utilisé dans le fichier CSV
        :return: Dictionnaire avec les différences détectées
        """

        expected_columns = list(json_schema.keys())

        with open(file_path, "r", encoding="utf-8") as f:
            reader = csv.reader(f, delimiter=delimiter)
            file_header = next(reader)  # Lire la première ligne (entête)

        mismatches = {
            "missing_columns": list(set(expected_columns) - set(file_header)),
            "extra_columns": list(set(file_header) - set(expected_columns)),
            "order_mismatch": file_header if file_header != expected_columns else []
        }
        result = all(not mismatches[key] for key in mismatches)
        return result, mismatches