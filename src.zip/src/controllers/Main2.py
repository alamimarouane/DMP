import csv
import json
from typing import List, Dict


def validate_csv_header(json_schema: Dict[str, Dict], file_path: str, delimiter: str = ",") -> Dict[str, List[str]]:
    """
    Compare l'entête du fichier CSV avec la structure JSON en termes de nombre, ordre et nomenclature des colonnes.

    :param json_schema: Structure JSON définissant les colonnes attendues
    :param file_path: Chemin du fichier CSV à valider
    :param delimiter: Délimiteur utilisé dans le fichier CSV
    :return: Dictionnaire avec les différences détectées
    """
    expected_columns = list(json_schema.keys())

    with open(file_path, "r", encoding="utf-8") as f:
        reader = csv.reader(f, delimiter=delimiter)
        file_header = next(reader)  # Lire la première ligne (entête)

    mismatches = {
        "missing_columns": list(set(expected_columns) - set(file_header)),
        "extra_columns": list(set(file_header) - set(expected_columns)),
        "order_mismatch": file_header if file_header != expected_columns else []
    }

    return mismatches


# Exemple d'utilisation
json_schema = {
    "id": {"type": "integer"},
    "name": {"type": "string"},
    "age": {"type": "integer"},
    "salary": {"type": "decimal"},
    "start_date": {"type": "date"},
    "last_login": {"type": "datetime"},
    "status": {"type": "string"},
    "score": {"type": "decimal"},
    "email": {"type": "string"},
    "is_verified": {"type": "boolean"}
}

file_path = "../../data/20250123/morocco/sgma/delta/bksldf.csv"
delimiter = ","
result = validate_csv_header(json_schema, file_path, delimiter)
print(result)
