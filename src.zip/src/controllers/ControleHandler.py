from src.context_manager.JsonAccessorManager import JsonAccessorManager
from src.logger.LogHandler import LogHandler


class ControleHandler:
    def __init__(self, successor=None):

        self.successor = successor

    def handle(self, key:str, accessor_manager: JsonAccessorManager, logger: LogHandler):

        if self.successor:
            return self.successor.handle(key, accessor_manager, logger)
        return True
