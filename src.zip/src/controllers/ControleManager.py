from logging import Logger

from src.context_manager.DataContext import DataContext
from src.context_manager.JsonAccessorManager import JsonAccessorManager
from src.controllers.DataValidator import DataValidator
from src.controllers.StructureValidationHandler import StructureValidationHandler
from src.controllers.WritenRowsValidationHandler import WritenRowsValidationHandler
from src.logger.LogHandler import LogHandler


class ControleManager:
    def __init__(self, key:str, accessor_manager: JsonAccessorManager, logger: LogHandler):

        self.key = key
        self.accessor_manager = accessor_manager
        self.flow_accessor = accessor_manager.get(self.key)
        self.logger = logger

        pass

    def validate(self, validation_rules_type):
        '''''
        if validation_rules_type == "pre_validation_rules":
            validation_rules = self.flow_accessor.get_pre_validation_rules()
            handler_classes = {
                "StructureValidationHandler": StructureValidationHandler,
            }
        else:
            if validation_rules_type == "post_validation_rules":
                validation_rules = self.flow_accessor.get_post_validation_rules()
                handler_classes = {
                    "WritenRowsValidationHandler": WritenRowsValidationHandler
                }

        handler_instances = [handler_classes[name] for name in validation_rules if name in handler_classes]
        '''
        validator = DataValidator(validation_rules_type, self.key, self.accessor_manager, self.logger)

        return validator.validate()