from abc import ABC, abstractmethod
from typing import Any


class AbstractSourceReader(ABC):
    """
    Abstract class for reading data from different sources.
    """

    @abstractmethod
    def read(self, source: str, as_dataframe: bool = False) -> Any:
        """
        Abstract method to read data from a given source.

        :param source: The path or identifier of the source to read.
        :param as_dataframe: If True, return the data as a Pandas DataFrame.
        :return: Data read from the source (Dict or DataFrame).
        """
        pass
