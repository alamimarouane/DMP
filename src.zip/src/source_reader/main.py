from src.source_reader.FlatFileSourceReader import FlatFileSourceReader
from src.source_reader.JsonSourceReader import JsonSourceReader

if __name__ == '__main__':
    sr = JsonSourceReader()
    d= sr.read("shared_config", "../../config/shared_config.json" , True)
    print(d)
    r=sr.get_rejections()

    sr = FlatFileSourceReader()
    f = sr.read("test", "../../data/test_data", True)
    #print(f)
    r=sr.get_rejections()
    #print(r)
