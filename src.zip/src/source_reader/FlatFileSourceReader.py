import pandas as pd
from pathlib import Path
from typing import Union, Dict, Any, List
from datetime import datetime

from src.context_manager.JsonAccessorManager import JsonAccessorManager
from src.logger.LogHandler import LogHandler
from src.source_reader.AbsractSourceReader import AbstractSourceReader

class FlatFileSourceReader(AbstractSourceReader):
    """
    Concrete implementation of AbstractSourceReader for reading flat files (CSV or TXT),
    rejecting only lines that do not match the expected header format while keeping valid ones.
    """

    def __init__(self, key:str, accessor_manager: JsonAccessorManager, logger: LogHandler, strict_mode: bool = False):
        """
        Initializes the FlatFileSourceReader with rejection handling.
        :param strict_mode: If True, raises an exception if any rejection occurs.
        """
        self.key = key
        self.accessor_manager = accessor_manager
        self.flow_accessor = accessor_manager.get(self.key)
        self.logger = logger

        self.flow_name = ""
        self.rejections: List[Dict[str, Any]] = []
        self.strict_mode = strict_mode

    def read(self, flow_name: str, source: str, as_dataframe: bool = False, delimiter: str = ",") -> Union[pd.DataFrame, Dict[str, Any]]:
        """
        Reads a flat file (CSV or TXT) and returns its content as a DataFrame or a dictionary,
        ensuring all columns are read as strings, rejecting only lines that do not match the expected header format.
        :param flow_name: Name of the data flow.
        :param source: Path to the flat file.
        :param as_dataframe: If True, returns the data as a Pandas DataFrame. If False, returns a dictionary.
        :param delimiter: The delimiter used in the file (default is ",").
        :return: A Pandas DataFrame or a dictionary containing the valid file data.
        """
        self.logger.log_step("Début de lecture du flux " + flow_name)
        self.flow_name = flow_name
        source_path = Path(source)
        if not source_path.exists():
            self._capture_rejection(None, None, "File not found", "Check the file path and ensure it exists.")
            self.logger.log_step(f"Chemin introuvalble (source_path) pour le flux {flow_name}")
            return None

        try:
            with open(source_path, "r", encoding="utf-8") as file:
                lines = file.readlines()

            if not lines:
                self._capture_rejection(None, None, "Empty file", "Ensure the file contains valid data.")
                message = f"Fichier vide {source_path}pour le flux {flow_name}"
                self.logger.log_step(message)
                return None

            expected_columns = lines[0].strip().split(delimiter)
            valid_lines = []

            for i, line in enumerate(lines[1:], start=2):
                values = line.strip().split(delimiter)
                if len(values) == len(expected_columns):
                    valid_lines.append(line)
                else:
                    self._capture_rejection(None, line.strip(), "Incorrect number of columns", "Ensure the row matches the header format.")

            if not valid_lines:
                print("No valid data to process after rejection.")
                message = f"Aucune donnée valide à traiter pour le flux {flow_name}"
                self.logger.log_step(message)
                return None

            # Efficiently load only valid lines into DataFrame and enforce all columns as string
            from io import StringIO
            df = pd.read_csv(StringIO("\n".join([lines[0]] + valid_lines)), delimiter=delimiter, dtype=str)
            message = f"Nombre de ligne(s) lue(s) : {len(df)} ligne(s) / nombre de ligne rejetées {len(self.get_rejections())} pour le flux {flow_name}"
            self.logger.log_step(message)
            return df if as_dataframe else df.to_dict(orient="records")

        except Exception as e:
            self._capture_rejection(None, None, f"Error reading file: {e}", "Verify the file format and delimiter.")
            message = f"Erreur lors e la lecture du fichier {source_path} pour le flux {flow_name}"
            self.logger.log_step(message)
            return None

    def _capture_rejection(self, column: str, value: Any, cause: str, proposition: str) -> Dict[str, Any]:
        """
        Captures and stores a rejection entry.
        :param column: The column name where the issue occurred.
        :param value: The rejected value.
        :param cause: The reason for the rejection.
        :param proposition: Suggested correction.
        :return: The rejection dictionary.
        """
        rejection = {
            "flow_name": self.flow_name,
            "datetime": datetime.now().isoformat(),
            "column": column,
            "value": value,
            "cause": cause,
            "proposition": proposition
        }
        self.rejections.append(rejection)
        return rejection

    def get_rejections(self) -> List[Dict[str, Any]]:
        """
        Returns the list of captured rejections.
        :return: A list of rejection dictionaries.
        """
        return self.rejections

    def get_rejections_as_dataframe(self) -> pd.DataFrame:
        """
        Convert the rejections into a structured DataFrame.
        :return: DataFrame of rejections.
        """
        if not self.rejections:
            return pd.DataFrame(columns=["column", "value", "cause", "proposition"])  # Default columns
        return pd.DataFrame(self.rejections)