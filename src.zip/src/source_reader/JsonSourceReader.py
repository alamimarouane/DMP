import json
import pandas as pd
from typing import Dict, Any, Union, List
from pathlib import Path
from datetime import datetime

from src.source_reader.AbsractSourceReader import AbstractSourceReader


class JsonSourceReader(AbstractSourceReader):
    """
    Concrete implementation of AbstractSourceReader for reading JSON files,
    with rejection handling.
    """

    def __init__(self, strict_mode: bool = False):
        """
        Initializes the JsonSourceReader with rejection handling.

        :param flow_name: Name of the data flow.
        :param strict_mode: If True, raises an exception if any rejection occurs.
        """
        self.rejections: List[Dict[str, Any]] = []
        self.strict_mode = strict_mode  # Mode strict : lève une exception en cas de rejets

    def read(self, flow_name: str, source: str, as_dataframe: bool = False) -> Union[Dict, pd.DataFrame]:
        """
        Reads a JSON file and returns its content as a dictionary or a DataFrame,
        with rejection handling.

        :param source: Path to the JSON file.
        :param as_dataframe: If True, returns the data as a Pandas DataFrame.
        :return: A dictionary or Pandas DataFrame containing the JSON data.
        """
        self.flow_name = flow_name
        source_path = Path(source)
        if not source_path.exists():
            rejection = self._capture_rejection(
                key=None,
                value=None,
                cause="File not found",
                proposition="Check the file path and ensure it exists."
            )
            if self.strict_mode:
                raise FileNotFoundError(f"File not found: {source}")
            return rejection

        try:
            with open(source_path, 'r', encoding='utf-8') as file:
                data = json.load(file)

            # Validate JSON structure
            if not isinstance(data, (dict, list)):
                rejection = self._capture_rejection(
                    key=None,
                    value=None,
                    cause="Invalid JSON format",
                    proposition="Ensure the JSON file contains a dictionary or a list."
                )
                if self.strict_mode:
                    raise ValueError("Invalid JSON format.")
                return rejection

            # Convert to DataFrame if requested
            if as_dataframe:
                if isinstance(data, list):  # JSON array of objects
                    df = pd.DataFrame(data)
                elif isinstance(data, dict):  # Single JSON object
                    df = pd.DataFrame([data])  # Convert to a one-row DataFrame
                else:
                    rejection = self._capture_rejection(
                        key=None,
                        value=None,
                        cause="Cannot convert JSON data to a DataFrame",
                        proposition="Ensure the JSON data is a list of dictionaries or a dictionary."
                    )
                    if self.strict_mode:
                        raise ValueError("Cannot convert JSON data to a DataFrame.")
                    return rejection

                # Check for missing values or invalid types in DataFrame
                for column in df.columns:
                    non_string_rows = df[~df[column].apply(lambda x: isinstance(x, str) or pd.isna(x))]
                    if not non_string_rows.empty:
                        self._capture_rejections(df, column, non_string_rows)

                if self.strict_mode and self.rejections:
                    raise ValueError(f"Rejections detected during file reading: {self.rejections}")

                return df

            return data

        except json.JSONDecodeError as e:
            rejection = self._capture_rejection(
                key=None,
                value=None,
                cause=f"Error decoding JSON: {e}",
                proposition="Check the file format and ensure it is valid JSON."
            )
            if self.strict_mode:
                raise ValueError(f"Error decoding JSON from file {source}: {e}")
            return rejection

    def _capture_rejection(self, key: str, value: Any, cause: str, proposition: str) -> Dict[str, Any]:
        """
        Captures and stores a rejection entry.

        :param key: The JSON key where the issue occurred.
        :param value: The rejected value.
        :param cause: The reason for the rejection.
        :param proposition: Suggested correction.
        :return: The rejection dictionary.
        """
        rejection = {
            "flow_name": self.flow_name,
            "datetime": datetime.now().isoformat(),
            "key": key,
            "value": value,
            "cause": cause,
            "proposition": proposition
        }
        self.rejections.append(rejection)
        return rejection

    def _capture_rejections(self, df: pd.DataFrame, column: str, rejected_rows: pd.DataFrame):
        """
        Captures all rejected values for a given column.

        :param df: The DataFrame being processed.
        :param column: The column where the rejection occurred.
        :param rejected_rows: Rows with invalid values.
        """
        for index, row in rejected_rows.iterrows():
            self.rejections.append({
                "flow_name": self.flow_name,
                "datetime": datetime.now().isoformat(),
                "key": column,
                "line_number": index + 1,  # Line number (1-based)
                "value": row[column],
                "cause": "Value is not a string",
                "proposition": f"Ensure the value in key '{column}' is a string."
            })

    def get_rejections(self) -> List[Dict[str, Any]]:
        """
        Returns the list of captured rejections.

        :return: A list of rejection dictionaries.
        """
        return self.rejections

    def get_rejections_as_dataframe(self) -> pd.DataFrame:
        """
        Convertit les rejets en un DataFrame structuré.

        :return: DataFrame des rejets.
        """
        if not self.rejections:
            return pd.DataFrame(columns=["column", "value", "error"])  # Définir des colonnes par défaut

        if all(isinstance(rejection, dict) for rejection in self.rejections):
            return pd.DataFrame(self.rejections)
        else:
            return pd.DataFrame([{"rejection": str(rejection)} for rejection in self.rejections])
