import os

from src.context_manager.DataContext import DataContext
from src.controllers.ControleManager import ControleManager
from src.exception_manager.ExceptionManager import ExceptionManager
from src.rejection_manager.RejectHandler import RejectHandler
from src.rejection_manager.RejectLogger import RejectLogger
from src.sink_writer.FileSinkWriterFactory import FileSinkWriterFactory
from src.sink_writer.SinkWriterClient import SinkWriterClient
from src.source_reader.FlatFileSourceReader import FlatFileSourceReader
from src.source_reader.JsonSourceReader import JsonSourceReader
from src.transformationManager_Save.TransformationManager import TransformationManager




if __name__ == '__main__':
    exception_manager = ExceptionManager("../../config/exceptions_config.json")
    exception_manager.setup_handlers()



    try:
        json_reader = JsonSourceReader()
        config = json_reader.read("Shared_config", "../../config/shared_config.json", False)
        execution_date = config.get("runtime_config")["execution_date"]

        country = "morocco"
        vertical = "sgma"
        source_system = "delta"
        flow_name = "bksldf"

        metadata_path = config.get("global_config")["scoped_metadata_root"] + "/" + country + "/" + vertical + "/" + source_system + "/" + flow_name + ".json"
        metadata = json_reader.read(flow_name, metadata_path, False)

        data_file_path = config.get("global_config")["data_root"] + "/" + execution_date +"/" + country + "/" + vertical + "/" + source_system + "/" +  flow_name + metadata.get("source")["extension"]

        output_data_file_path = config.get("global_config")[
                             "data_output_root"] + "/" + execution_date + "/" + country + "/" + vertical + "/" + source_system + "/" + flow_name + \
                         metadata.get("source")["extension"]
        output_reject_data_file_path = config.get("global_config")[
                                    "data_output_root"] + "/" + execution_date + "/" + country + "/" + vertical + "/" + source_system + "/" + flow_name + "_rjt" +  \
                                metadata.get("source")["extension"]
        # Lecture des données:


        flat_file_reader = FlatFileSourceReader()
        data = flat_file_reader.read(flow_name, data_file_path, True)

        data_context = DataContext(data, metadata, config)

        # validation : pre controles
        controle_manager = ControleManager()

        if controle_manager.validate("pre_validation_rules", data_context):
            print("Data is valid.")
            # Transformer
            transformation_manager = TransformationManager(data_context)
            reject_handler = RejectHandler()
            reject_logger = RejectLogger()

            # Attach the reject handler
            transformation_manager.attach(reject_handler)
            transformation_manager.attach(reject_logger)

            # Appliquer les transformations
            df_transformed = transformation_manager.apply_transformations()

            # Afficher les rejets
            rejections = transformation_manager.get_rejections_as_dataframe()


            #Ecriture des données
            file_factory = FileSinkWriterFactory()
            file_client = SinkWriterClient(file_factory)
            print(output_data_file_path)
            print(output_reject_data_file_path)
            print(rejections)
            file_client.write_data(df_transformed, output_data_file_path)
            file_client.write_data(rejections, output_reject_data_file_path)



        else:
            print("Data is invalid.")



    except Exception as e:
        exception_manager.handle(e, {"classe": __name__})
        print(exception_manager.get_error_info(e))
