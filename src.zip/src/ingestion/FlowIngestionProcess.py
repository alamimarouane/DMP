
from src.context_manager.JsonAccessorManager import JsonAccessorManager
from src.controllers.ControleManager import ControleManager
from src.exception_manager.ExceptionManager import ExceptionManager
from src.logger.LogHandler import LogHandler
from src.sink_writer.FileSinkWriterFactory import FileSinkWriterFactory
from src.sink_writer.SinkWriterClient import SinkWriterClient
from src.source_reader.FlatFileSourceReader import FlatFileSourceReader
from src.transformationManager.RejectionManager import RejectionManager
from src.transformationManager.TransformationManager import TransformationManager

class FlowIngestionProcess:
    def __init__(self, accessor_manager: JsonAccessorManager, country: str, vertical: str,
                 source_system: str, flow_name: str, exception_manager: ExceptionManager):
        """
        Initialise un processus d'ingestion avec les paramètres requis.
        :param country: Pays concerné
        :param vertical: Verticale métier
        :param source_system: Système source des données
        :param flow_name: Nom du flux à traiter
        """
        self.accessor_manager = accessor_manager
        self.exception_manager = exception_manager
        self.key = country + "-" + vertical + "-" + source_system + "-" + flow_name
        self.flow_accessor = accessor_manager.get(self.key)
        self.config = accessor_manager.get("shared_config")
        self.execution_date = self.config.get_runtime_config_execution_date()
        self.build_paths()
        self.logger = LogHandler(self.accessor_manager, "Ingestion")
        self.init_reader_writer()
        self.flow_name = self.flow_accessor.get_flow_name()

    def run(self) -> bool:
        self.logger.log_start(0, "Démarrage du traitement d'ingestion pour le flux : " + self.flow_name)
        try:
            self.logger.log_step("Chargement de la configuration pour le flux : "  + self.flow_name)

            # validation : pre controles
            controle_manager = ControleManager(self.key, self.accessor_manager, self.logger)
            pre_controle = controle_manager.validate("pre_validation_rules")
            if pre_controle:
                self.logger.log_step("Pre-control sur le flux : OK")

                self.read()
                self.transform()

                post_controle = controle_manager.validate("post_validation_rules")
                if post_controle:
                    self.logger.log_complete(0, "Fin du traitement d'ingestion pour le flux : " + self.flow_name)
                #if self.origin_rows == self.written_rows :
                    #self.logger.log_complete(0, "Fin du traitement d'ingestion pour le flux : " + self.flow_name)
                    #return True
                else:
                    self.logger.log_step(f"Perte de lignes lors de l'ecriture des données {self.origin_rows - self.written_rows}")
                    self.logger.log_fail(-2, "Erreur du traitement d'ingestion pour le flux : " + self.flow_name + " : perte des données")
                    return False
            else:
                self.logger.log_step("Control sur le flux : KO")
                self.logger.log_fail(-1, "Erreur du traitement d'ingestion pour le flux : " + self.flow_name + " : erreur de validation des données")
                return False

        except Exception as e:
            self.exception_manager.handle(e, {"classe": __name__})
            self.logger.log_fail(-2, "Erreur du traitement d'ingestion pour le flux : " + self.flow_name )
            return False

    def build_paths(self):
        key_to_path = self.key.replace("-", "/")
        self.output_data_file_path = self.config.get("global_config").get(
            "data_output_root") + "/" + self.execution_date + "/" + key_to_path + \
                                     self.flow_accessor.get_source_extension()

        self.reject_transformed_data_file_path = self.config.get("global_config").get(
            "data_output_root") + "/" + self.execution_date + "/" + key_to_path + "_trans_rjt" + \
                                                 self.flow_accessor.get_source_extension()
        self.reject_readed_data_file_path = self.config.get("global_config")[
                                                "data_output_root"] + "/" + self.execution_date + "/" + key_to_path + "_readed_rjt" + \
                                            self.flow_accessor.get_source_extension()
        self.data_file_path = self.config.get("global_config")[
                                  "data_root"] + "/" + self.execution_date + "/" + key_to_path + \
                              self.flow_accessor.get_source_extension()
        self.flow_accessor.set("data_file_path", self.data_file_path)
        self.accessor_manager.update_accessor(self.key, self.flow_accessor)
        pass
    def transform(self):
        # Début de transformation
        self.logger.log_step("Transformation primitives sur le flux : ...")

        transformation_rules = self.flow_accessor.get_transformation_rules()
        rejection_manager = RejectionManager()
        transformation_manager = TransformationManager(rejection_manager, transformation_rules)
        transformed_data = transformation_manager.apply_transformation(self.origin_data)
        rejected_data = rejection_manager.get_rejections()



        # Fin des transformations

        # Ecriture des données
        self.origin_rows, self.written_rows = self.file_client.write_data(transformed_data, self.output_data_file_path)
        self.file_client.write_data(rejected_data, self.reject_transformed_data_file_path)
        # Fin ecriture des données

    def read(self):
        self.origin_data = self.flat_file_reader.read(self.flow_name, self.data_file_path, True)
        rejected_readed_data = self.flat_file_reader.get_rejections_as_dataframe()
        self.file_client.write_data(rejected_readed_data, self.reject_readed_data_file_path)


    def init_reader_writer(self):
        self.flat_file_reader = FlatFileSourceReader(self.key, self.accessor_manager, self.logger)
        file_factory = FileSinkWriterFactory()
        self.file_client = SinkWriterClient(self.key, self.accessor_manager, file_factory, self.logger)