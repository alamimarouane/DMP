from src.context_manager.JsonAccessorManager import JsonAccessorManager
from src.exception_manager.ExceptionManager import ExceptionManager
from src.ingestion.FlowIngestionProcess import FlowIngestionProcess
from src.logger.LogHandler import LogHandler
from src.source_reader.JsonSourceReader import JsonSourceReader


class SystemIngestionProcess:
    def __init__(self, accessor_manager: JsonAccessorManager, country: str, vertical: str, source_system: str, exception_manager: ExceptionManager):
        """
        Initialise le processus d'exécution des flux d'ingestion.
        :param config: Configuration du système
        :param country: Pays concerné
        :param vertical: Verticale métier
        :param source_system: Système source des données
        """

        self.accessor_manager = accessor_manager
        self.exception_manager = exception_manager
        self.country = country
        self.vertical = vertical
        self.source_system = source_system
        self.key = country + "-" + vertical + "-" + "dag"

    def run(self):
        """
        Exécute les flux d'ingestion définis dans la configuration DAG en prenant en compte la notion de "disable".
        """

        try:
            dag_config = self.accessor_manager.get(self.key).get_metadata()
            phases = dag_config.get("verticals", {}).get(self.vertical, {}).get("phases", {})
            ingestion = phases.get("ingestion", {}).get("systeme_source", {}).get(self.source_system, {})

            if "flux" not in ingestion:
                print(f"Aucun flux défini pour {self.source_system} dans l'ingestion.")
                return

            for flow in ingestion["flux"]:
                flow_name = flow["name"]
                mandatory = flow["mandatory"]
                disable = flow.get("disable", False)

                if disable:
                    print(f"Flux {flow_name} est désactivé. Il ne sera pas exécuté.")
                    continue

                print(f"Execution du flux: {flow_name}")
                accessor_manager = JsonAccessorManager()
                accessor_manager.add_from_directory("../../metadata/scoped")
                accessor_manager.add_from_directory("../../config")

                process = FlowIngestionProcess(accessor_manager, self.country, self.vertical, self.source_system, flow_name, self.exception_manager)
                success =process.run()

                if not success and mandatory:
                    print(
                        f"Erreur critique: le flux obligatoire {flow_name} a échoué. Arrêt du traitement avec code d'erreur 1.")
                    return False
                elif not success:
                    print(f"Flux {flow_name} a échoué mais est optionnel. Poursuite du traitement.")
                    continue

        except Exception as e:
            self.exception_manager.handle(e, {"classe": __name__})
            print(self.exception_manager.get_error_info(e))
            return False
