from src.context_manager.JsonAccessorManager import JsonAccessorManager
from src.exception_manager.ExceptionManager import ExceptionManager
from src.ingestion.FlowIngestionProcess import FlowIngestionProcess
from src.ingestion.SystemIngestionProcess import SystemIngestionProcess
from src.logger.LogHandler import LogHandler

from src.source_reader.JsonSourceReader import JsonSourceReader

if __name__ == '__main__':
    accessor_manager = JsonAccessorManager()
    accessor_manager.add_from_directory("../../metadata/scoped")
    accessor_manager.add_from_directory("../../config")

    exception_manager = ExceptionManager(accessor_manager)
    exception_manager.setup_handlers()

    process = SystemIngestionProcess(accessor_manager, "morocco", "sgma", "delta",  exception_manager)
    process.run()

